<?php
/**
 * CartException.php
 *
 * @copyright  2023 beikeshop.com - All Rights Reserved
 * @link       https://beikeshop.com
 * @author     Edward Yang <yangjin@guangda.work>
 * @created    2023-06-02 17:08:18
 * @modified   2023-06-02 17:08:18
 */

namespace Beike\Exceptions;

class CartException extends \Exception
{
}
