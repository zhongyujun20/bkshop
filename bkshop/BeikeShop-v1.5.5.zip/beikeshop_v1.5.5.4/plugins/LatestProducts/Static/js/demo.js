/**
 * 这里是插件js, 请在blade里面使用以下代码引入
 * <script src="{{ asset('plugin/stripe/js/demo.js') }}"></script>
 */
