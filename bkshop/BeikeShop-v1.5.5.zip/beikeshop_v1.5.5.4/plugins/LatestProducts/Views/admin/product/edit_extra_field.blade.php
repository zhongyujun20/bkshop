<x-admin-form-input name="custom_field" :title="'自定义字段'" :value="old('custom_field', $product->custom_field ?? '')" />
