<?php
/**
 * Lang.php
 *
 * @copyright  2023 beikeshop.com - All Rights Reserved
 * @link       https://beikeshop.com
 * @author     Edward Yang <yangjin@guangda.work>
 * @created    2023-09-09 09:09:09
 * @modified   2023-09-08 10:18:27
 */

return [
    'latest_products' => 'Prodotti più recenti',
];
